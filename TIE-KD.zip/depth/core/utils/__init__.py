# Copyright (c) OpenMMLab. All rights reserved.
from .misc import add_prefix

__all__ = ['add_prefix']
